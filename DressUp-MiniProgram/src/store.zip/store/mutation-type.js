export const RECEIVE_LIST = 'receive_list'  //
export const MOVIES_ARR = 'movies_arr'    //
export const OPENID = 'openId'      //我的id
export const MYWXINFO = 'myWxInfo'  //我的微信资料
export const MYCOSINFO = 'myCosInfo'  //我的自定义资料